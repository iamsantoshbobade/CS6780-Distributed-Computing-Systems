package client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import server.BackgroundThread;

public class NormalSocketClientThread implements Runnable {

	private int nport = 0;
	private int tport = 0;

	private String hostname = null;
	private HashMap<Integer, Thread> terminateCommands = null;

	private Socket normalSocket = null;
	private OutputStream outputStream = null;
	private PrintWriter printWriter = null;
	private InputStream inputStream = null;
	private BufferedReader bufferedReader = null;
	private BufferedReader streamReader = null;

	public NormalSocketClientThread(String hostname, int nport, int tport, HashMap<Integer, Thread> terminateCommands) {
		System.out.println("In constrructor of Normal Client");
		this.hostname = hostname;
		this.nport = nport;
		this.tport = tport;
		this.terminateCommands = terminateCommands;
		try {
			normalSocket = new Socket(hostname, nport);
			outputStream = normalSocket.getOutputStream();
			printWriter = new PrintWriter(outputStream, true);
			inputStream = normalSocket.getInputStream();
			bufferedReader = new BufferedReader(new InputStreamReader(System.in));
			streamReader = new BufferedReader(new InputStreamReader(inputStream));

		} catch (Exception e) {
			System.out.println("Exception occured in creating normal client socket: " + e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		System.out.println("In run method of Normal Client");

		try {
			String userInp = "";
			while (!userInp.equalsIgnoreCase("quit")) {

				System.out.print("myftp>");
				userInp = bufferedReader.readLine();
				if (userInp.length() == 0)
					continue;
				if ((!userInp.split(" ")[0].equalsIgnoreCase("put") && !userInp.split(" ")[0].equalsIgnoreCase("get"))
						&& !(userInp.split(" ")[0]).equals("terminate"))
					printWriter.println(userInp);
				String command = userInp.split(" ")[0];
				String serverStream = null;

				switch (command) {

				case "get":
					printWriter.println("pwd");
					String dir = streamReader.readLine();
					executeGet(userInp, dir); {
					/*
					 * 
					 * if (!(userInp.split(" ").length > 1)) {
					 * System.out.println(
					 * "Incorrect usage. Correct usage get <filename>"); break;
					 * // correct usage check }
					 * 
					 * Path path = Paths.get(userInp.split(" ")[1]); File file =
					 * path.toFile();
					 * 
					 * //if background true if (!file.exists() &&
					 * userInp.endsWith(" &")) {
					 * printWriter.println("getterminateid" + " " +
					 * userInp.split(" ")[1]);
					 * 
					 * // read stream and print id here String incomming =
					 * streamReader.readLine();; int commandId =
					 * Integer.parseInt(incomming.split(",")[0]);
					 * System.out.println("Get Command ID Received: " +
					 * commandId);
					 * 
					 * // Spawn a thread here Thread t = new Thread(new
					 * BackgroundThread("get", userInp.split(" ")[1],
					 * normalSocket, true,
					 * Integer.parseInt(incomming.split(",")[1])));
					 * terminateCommands.put(commandId, t); t.start(); break; }
					 * // if background false else { if(!file.exists()){
					 * 
					 * printWriter.println("length " + userInp.split(" ")[1]);
					 * int length = Integer.parseInt(streamReader.readLine());
					 * 
					 * printWriter.println(userInp);
					 * 
					 * if (length < 0) {
					 * System.out.println(streamReader.readLine()); break; }
					 * 
					 * FileOutputStream fos = new
					 * FileOutputStream(userInp.split(" ")[1]); byte[] fileBytes
					 * = new byte[length]; inputStream.read(fileBytes);
					 * fos.write(fileBytes); fos.close(); break; } else {
					 * System.out.println("File " + file.getName() +
					 * " already exists"); break; } }
					 */}
					break;
				case "put":
					printWriter.println("pwd");
					String currDir = streamReader.readLine();
					executePut(userInp, currDir); 
					
					break;
					/*
					 * if (!(userInp.split(" ").length > 1)) {
					 * System.out.println("Incorrect command " +
					 * "correct usage put <filename>"); break; } Path path =
					 * Paths.get(userInp.split(" ")[1]); File f = path.toFile();
					 * boolean background = userInp.endsWith(" &"); if
					 * (background && f.exists()) { printWriter.println(userInp
					 * + " " + f.length());
					 * 
					 * // read stream and print id here int commandId =
					 * Integer.parseInt(streamReader.readLine());
					 * System.out.println("Put Command ID Received: " +
					 * commandId);
					 * 
					 * // Spawn a thread here Thread t = new Thread( new
					 * BackgroundThread("put", userInp, normalSocket, true,
					 * (int) f.length())); terminateCommands.put(commandId, t);
					 * t.start(); break; } else { FileInputStream fis = new
					 * FileInputStream(f); byte[] fileBytes = new byte[(int)
					 * f.length()]; printWriter.println(userInp + " " +
					 * fileBytes.length); fis.read(fileBytes);
					 * outputStream.write(fileBytes); fis.close(); } break;
					 */
				case "delete":
					String str = streamReader.readLine();
					if (!str.endsWith("IGNORE"))
						System.out.println(str);
					break;
				case "terminate":
					Integer commandId = Integer.valueOf(userInp.split(" ")[1]);
					Thread t = new Thread(new TerminateSocketClientThread(hostname, tport, commandId));
					t.start();
					System.out.println("*Swicth terminate case client*" + streamReader.readLine() + "**");
					System.out.println("Terminating.. " + userInp.split(" ")[1]);

					break;
				case "quit":
					break;
				default:
					serverStream = streamReader.readLine();
					if (serverStream != null && !serverStream.endsWith("IGNORE"))
						System.out.println(serverStream);
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occured in run method of client worker");
			e.printStackTrace();
		}

	}

	private void executeGet(String input, String workingDir) {
		if (!(input.split(" ").length > 1)) {
			System.out.println("Incorrect usage. Correct usage get <filename>");
			return; // correct usage check
		}

		Path path = Paths.get(input.split(" ")[1]);
		File file = path.toFile();

		if (file.exists()) {
			System.out.println("File " + file.getName() + " already exists.");
			return;
		}

		if (input.endsWith(" &")) {
			// spawn a thread here
			System.out.println("Execute get method in client");
			Thread backgroundThread = new Thread(new ClientBackgroundThread(hostname, nport, input, workingDir, "get"));
			backgroundThread.start();
			return;
		} else {
			// normal operation
			printWriter.println("length " + workingDir + File.separator + input.split(" ")[1]);
			int length = 0;
			try {
				length = Integer.parseInt(streamReader.readLine());
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			printWriter.println(input);
			String result;
			try {
				if (length < 0) {
					result = streamReader.readLine();
					if (result.equals("Fail"))
						System.out.println("File: " + input.split(" ")[1] + " does not exist.");

				}

				else {
					FileOutputStream fos = new FileOutputStream(input.split(" ")[1]);
					byte[] fileBytes = new byte[length];
					System.out.println("File transfer started");
					inputStream.read(fileBytes);
					fos.write(fileBytes);
					fos.close();
					System.out.println("File transfer complete");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	private void executePut(String input, String workingDir) {
		
		if (!(input.split(" ").length > 1)) {
			System.out.println("Incorrect usage. Correct usage put <filename>");
			return; // correct usage check
		}
		
		

	}

}
