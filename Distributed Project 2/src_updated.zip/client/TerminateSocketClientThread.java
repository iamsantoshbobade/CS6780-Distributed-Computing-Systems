package client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class TerminateSocketClientThread implements Runnable {

	private int tport;
	private int commandId;
	private String hostName;
	private Socket terminateSocket = null;

	private OutputStream outputStream = null;
	private PrintWriter printWriter = null;
	private InputStream inputStream = null;
	private BufferedReader streamReader = null;

	public TerminateSocketClientThread(String hostName, int tport, int commandId) {
		System.out.println("In constructor of Terminate Client");
		this.tport = tport;
		this.hostName = hostName;
		this.commandId = commandId;
		try {
			terminateSocket = new Socket(hostName, tport);
			outputStream = terminateSocket.getOutputStream();
			printWriter = new PrintWriter(outputStream, true);
			inputStream = terminateSocket.getInputStream();
			//bufferedReader = new BufferedReader(new InputStreamReader(System.in));
			streamReader = new BufferedReader(new InputStreamReader(inputStream));
		} catch (Exception e) {
			System.out.println("Exception occured in creating terminate client thread: " + e.getMessage());
		}
	}

	@Override
	public void run() {
		System.out.println("in run method of terminate thread");
		try {
			printWriter.println(this.commandId);
			String result = streamReader.readLine();
			System.out.println("Result: "+result);
			//Thread.currentThread().interrupt();
			/*terminateSocket.close();
			outputStream.close();
			inputStream.close();
			printWriter.flush();
			printWriter.close();*/
			

		} catch (Exception e) {
			System.out.println("Exception occured in run method of Terminate Client Thread: " + e.getMessage());
			e.printStackTrace();
		}

	}

}
