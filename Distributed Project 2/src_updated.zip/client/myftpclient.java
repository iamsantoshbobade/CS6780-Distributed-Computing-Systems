package client;

import java.util.HashMap;

public class myftpclient {

	private int nport = 0;
	private int tport = 0;
	private String hostName;

	NormalSocketClientThread normalSocketClientThread = null;
	//TerminateSocketClientThread terminateSocketClientThread = null;
	
	private HashMap<Integer, Thread> terminateCommands = null;

	public myftpclient(String hostName, int nport, int tport) {
		this.nport = nport;
		this.tport = tport;
		this.hostName = hostName;
		terminateCommands = new HashMap<Integer, Thread>();
	}

	public NormalSocketClientThread getNormalSocketClientThread() {
		if (normalSocketClientThread == null) {
			normalSocketClientThread = new NormalSocketClientThread(this.hostName, this.nport, this.tport, terminateCommands);
		}
		return normalSocketClientThread;
	}

	public void setNormalSocketClientThread(NormalSocketClientThread normalSocketClientThread) {
		this.normalSocketClientThread = normalSocketClientThread;
	}

	public static void main(String[] args) {

		//myftpclient ftpclient = new myftpclient(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
		myftpclient ftpclient = new myftpclient("localhost", 1234, 1235);
		Thread nthread = new Thread(ftpclient.getNormalSocketClientThread());
		nthread.start();

	}

}
