package client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ClientBackgroundThread implements Runnable{
	
	private String hostname = null;
	private int nport = 0;
	
	private Socket socket = null;
	private OutputStream outputStream = null;
	private PrintWriter printWriter = null;
	private InputStream inputStream = null;
	private BufferedReader streamReader = null;
	private int fileLength = 0;
	private String operation = null;
	private String PWD = null;
	private boolean client = true;
	private String filepath = null;
	private String filename = null;
	
	public ClientBackgroundThread(String hostname, int nport, String input, String workingDir,String operation) {
		this.hostname = hostname;
		this.nport = nport;
		PWD = workingDir;
		
		try {
			socket = new Socket(hostname, nport);
			outputStream = socket.getOutputStream();
			printWriter = new PrintWriter(outputStream, true);
			inputStream = socket.getInputStream();
			this.operation = operation;
			//backgroundBufferedReader = new BufferedReader(new InputStreamReader(System.in));
			streamReader = new BufferedReader(new InputStreamReader(inputStream));
			//printWriter.println("pwd");
			//PWD = streamReader.readLine();
			
			
			printWriter.println("getterminateid"+" "+PWD+File.separator+input.split(" ")[1]);
			String incoming = streamReader.readLine();
			Integer commandId = Integer.valueOf(incoming.split(",")[0]);
			this.fileLength = Integer.parseInt(incoming.split(",")[1]);
			this.filepath = PWD+File.separator+input.split(" ")[1];
			if(this.fileLength > 0){
				System.out.println("Command ID Received: "+commandId);//+"\t length: "+fileLength);
				filename = input.split(" ")[1];
			}else{
				System.out.println("File: "+input.split(" ")[1]+" does not exist.");
			}
			
			
			//byteStream = new DataInputStream(socket.getInputStream());
			//dStream = new DataOutputStream(oStream);
			
			
			
		} catch (Exception e) {
			System.out.println("Exception occured in calling Client Worker constructor: " + e.getMessage());
			e.printStackTrace();
		}
		
		
		
	}
	

	@Override
	public void run() {
		//System.out.println("before run bg thread");
		if(this.fileLength < 0){
			return;
		}
		//System.out.println("after run bg thread");
		

		try {
			OutputStream outStr = socket.getOutputStream();
			if(this.operation != null && this.operation.equals("get") && !client){
				Path p = Paths.get(this.filepath);
				File file = p.toFile();
				byte[] fileBytes = new byte[(int) file.length()];

				FileInputStream fis = new FileInputStream(file);
				fis.read(fileBytes);
				System.out.println(fileBytes);
				outStr.write(fileBytes);
				fis.close();
			}
			else if(this.operation.equals("get") && client){

				InputStream ips = socket.getInputStream();
				FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+File.separator+filename);
				byte[] fileBytes = new byte[this.fileLength];
				ips.read(fileBytes);
				fos.write(fileBytes);
				fos.close();
			}
			
			//put operation
			if(this.operation != null && this.operation.equals("put") && !client){
				FileOutputStream fos = new FileOutputStream(filepath);
				InputStream ins = socket.getInputStream();
				byte[] b = new byte[this.fileLength];
				ins.read(b);
				fos.write(b);
				fos.close();
			}
			else if(this.operation.equals("put") && client){
				
				Path path = Paths.get(filepath.split(" ")[1]);
				File f = path.toFile();
				if(f.exists()){
					FileInputStream fis = new FileInputStream(f);
					byte[] fileBytes = new byte[this.fileLength];
					fis.read(fileBytes);
					outStr.write(fileBytes);
					fis.close();
				}
				else{
					System.out.println("The file "+ f.getName() + " does not exist");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
	}
	
	

}
