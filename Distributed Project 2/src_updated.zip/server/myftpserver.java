package server;

import java.util.HashMap;

public class myftpserver {
	private int nport = 0;
	private int tport = 0;
	NormalSocketServerThread normalSocketServerThread = null;
	TerminateSocketServerThread terminateSocketServerThread = null;

	private HashMap<Integer, Thread> terminateCommands = null;
	

	public NormalSocketServerThread getNormalSocketServerThread() {
		if (normalSocketServerThread == null) {
			normalSocketServerThread = new NormalSocketServerThread(nport, terminateCommands);
		}
		return normalSocketServerThread;
	}

	public void setNormalSocketServerThread(NormalSocketServerThread normalSocketServerThread) {
		this.normalSocketServerThread = normalSocketServerThread;
	}

	public TerminateSocketServerThread getTerminateSocketServerThread() {
		if (terminateSocketServerThread == null) {
			terminateSocketServerThread = new TerminateSocketServerThread(tport, terminateCommands);
		}
		return terminateSocketServerThread;
	}

	public void setTerminateSocketServerThread(TerminateSocketServerThread terminateSocketServerThread) {
		this.terminateSocketServerThread = terminateSocketServerThread;
	}

	public myftpserver(int nport, int tport) {
		this.nport = nport;
		this.tport = tport;
		terminateCommands = new HashMap<Integer, Thread>();

	}

	public static void main(String[] args) {
		// myftpserver ftpserver = new myftpserver(Integer.parseInt(args[0]),
		// Integer.parseInt(args[1]));
		myftpserver ftpserver = new myftpserver(1234, 1235);
		try {
			// start 2 threads here
			Thread nthread = new Thread(ftpserver.getNormalSocketServerThread());
			Thread tthread = new Thread(ftpserver.getTerminateSocketServerThread());
			nthread.start();
			tthread.start();
		} catch (Exception e) {
			System.out.println("Exception occured while launching server.. " + e.getMessage());
			e.printStackTrace();
		}
	}

}
