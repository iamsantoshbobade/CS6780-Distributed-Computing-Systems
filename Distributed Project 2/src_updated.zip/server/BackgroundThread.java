package server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

public class BackgroundThread implements Runnable {

	private String operation = "";
	private String filepath = "";
	private Socket socket = null;
	private boolean client = false;
	private int length = 0;

	public BackgroundThread(String operation, String filepath, Socket socket, boolean client, int length) {
		this.operation = operation;
		this.filepath = filepath;
		this.socket = socket;
		this.client = client;
		this.length = length;
	}
	

	@Override
	public void run() {
		try {
			OutputStream outStr = socket.getOutputStream();
			if(this.operation != null && this.operation.equals("get") && !client){
				Path p = Paths.get(this.filepath);
				File file = p.toFile();
				byte[] fileBytes = new byte[(int) file.length()];

				FileInputStream fis = new FileInputStream(file);
				fis.read(fileBytes);
				System.out.println(fileBytes);
				outStr.write(fileBytes);
				fis.close();
			}
			else if(this.operation.equals("get") && client){

				InputStream ips = socket.getInputStream();
				FileOutputStream fos = new FileOutputStream(this.filepath);
				byte[] fileBytes = new byte[this.length];
				ips.read(fileBytes);
				fos.write(fileBytes);
				fos.close();
			}
			
			//put operation
			if(this.operation != null && this.operation.equals("put") && !client){
				FileOutputStream fos = new FileOutputStream(filepath);
				InputStream ins = socket.getInputStream();
				byte[] b = new byte[length];
				ins.read(b);
				fos.write(b);
				fos.close();
			}
			else if(this.operation.equals("put") && client){
				
				Path path = Paths.get(filepath.split(" ")[1]);
				File f = path.toFile();
				if(f.exists()){
					FileInputStream fis = new FileInputStream(f);
					byte[] fileBytes = new byte[length];
					fis.read(fileBytes);
					outStr.write(fileBytes);
					fis.close();
				}
				else{
					System.out.println("The file "+ f.getName() + " does not exist");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
