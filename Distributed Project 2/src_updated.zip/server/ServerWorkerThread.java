package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import client.ClientBackgroundThread;

public class ServerWorkerThread implements Runnable {

	Socket socket = null;
	BufferedReader bufferedReader = null;
	InputStream inputStream = null;
	PrintWriter printWriter = null;
	HashMap<Integer, Thread> terminateCommands;

	private String PWD = null;

	public ServerWorkerThread(Socket socket, HashMap<Integer, Thread> terminateCommands) {
		this.socket = socket;
		this.terminateCommands = terminateCommands;
		PWD = System.getProperty("user.dir");
		//System.out.println("In constructor of Server Worker Thread");
	}

	private Integer getCommandId() {
		Integer commandId = (int) (Math.random() * (100000 - 10));
		return commandId;
	}

	private void insertCommandId(Integer commandId) {
		terminateCommands.put(commandId, Thread.currentThread());
	}

	@Override
	public void run() {
		//System.out.println("In run of Server Worker Thread");
		boolean flag = true;

		try {
			inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();

			printWriter = new PrintWriter(outputStream, true);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String clientData = "";

			while (flag) {
				clientData = bufferedReader.readLine();
				String command = interpret(clientData);
				if (command != null) {
					switch (command) {
					case "pwd":
						printWriter.println(PWD);
						break;
					case "cd":
						String words[] = clientData.trim().split(" ");
						if (words.length > 1) {
							if (words[1].trim().equals("..")) {
								int indexOfLastSlash = PWD.lastIndexOf(File.separator);
								if (indexOfLastSlash != 0) {
									// if (indexOfLastSlash != -1) {
									String temp = PWD.substring(0, indexOfLastSlash);
									PWD = temp;
									printWriter.println("CD COMMAND IGNORE");
									// }
								} else {
									printWriter.println("Already in the root directory.");
								}

							} else {
								File f = new File(words[1].trim());
								if (f.exists() && f.isDirectory() && f.isAbsolute()) {
									PWD = words[1].trim();
									printWriter.println("CD COMMAND IGNORE");
								} else {
									File file = new File(PWD + File.separator + words[1].trim());
									if (file.exists()) {
										if (file.isDirectory()) {
											PWD = PWD + File.separator + words[1].trim();
											printWriter.println("CD COMMAND IGNORE");
										} else {
											printWriter.println("cd: " + words[1] + ": Not a directory");
										}
									} else {
										printWriter.println("cd: " + words[1] + ": No such file or directory");
									}
								}

							}
						} else {
							printWriter.println("Only cd .. and cd <directory-name> are supported.");
						}
						break;
					case "mkdir":
						words = clientData.trim().split(" ");
						if (words.length > 1) {
							File file = new File(PWD + File.separator + words[1].trim());
							boolean fileExists = file.exists();
							if (!fileExists) {
								file.mkdir();
								printWriter.println("MKDIR COMMAND IGNORE");
							} else {
								printWriter.println("File: " + words[1].trim() + " already exists.");
							}
						} else {
							printWriter.println("mkdir: missing operand. Correct usage: mkdir <directory-name>");
						}
						break;

					case "delete":
						words = clientData.trim().split(" ");
						if (words.length > 1) {
							File file = new File(PWD + File.separator + words[1].trim());
							if (file.exists() && !file.isDirectory()) {
								file.delete();
								printWriter.println("DELETE COMMAND IGNORE");
							} else if (file.isDirectory()) {
								printWriter.println("Can not delete directory using delete.");
							} else if (!file.exists()) {
								printWriter.println("File does not exist.");
							}
						} else {
							printWriter.println("delete: missing operand. Correct usage: delete <filename>");
						}
						break;

					case "ls":
						File file = new File(PWD);
						String directoryList[] = file.list();
						String temp = "";
						for (String directory : directoryList) {
							temp = temp + directory + "\t";
						}
						printWriter.println(temp);
						break;

					case "length":
						int length = findLength(clientData.split(" ")[1]);
						printWriter.println(length);
						break;

					case "getterminateid":
						int commandId = getCommandId();
						insertCommandId(commandId);
						int len = findLength(clientData.split(" ")[1]);
						printWriter.println(commandId + "," + len);
						if(len >= 0){
							executeGet(clientData.split(" ")[1], socket, true);
						}else{
							terminateCommands.remove(commandId);
						}
						break;
						
						/*if(clientData.split(" ").length > 2)
							executeGet(clientData, socket, true);
						else
							executeGet(clientData, socket, false);
						break;*/

					case "get":
						/*if(clientData.split(" ").length > 2)
							executeGet(clientData, socket, true);
						else
							executeGet(clientData, socket, false);
						break;*/
						executeGet(PWD + File.separator + clientData.split(" ")[1], socket, false);
						/*if (str != null && !str.endsWith("IGNORE")) {
							pw.println(str);
						}*/
						
						break;

					case "put":

						if(clientData.split(" ").length > 3)
							executePut(clientData, socket, true);
						else
							executePut(clientData, socket, false);
						break;
						
					case "quit":
						flag = false;
						break;

					default:
						printWriter.println("Invalid command " + command);
						break;
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Exception occured in run of Server Worker Thread: " + e.getMessage());
			e.printStackTrace();
		}
		finally {
			try{
				bufferedReader.close();
				inputStream.close();
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void executePut(String clientData, Socket socket, boolean background) {

		try{
			if(!background){
				FileOutputStream fos = new FileOutputStream(PWD + File.separator + clientData.split(" ")[1]);
				InputStream ins = socket.getInputStream();
				byte[] b = new byte[Integer.parseInt(clientData.split(" ")[2])];
				ins.read(b);
				fos.write(b);
				fos.close();
			}
			else {
				int commandId = this.getCommandId();
				printWriter.println(commandId);

				String filepath = PWD + File.separator + clientData.split(" ")[1];
				Thread t = new Thread(new BackgroundThread("put", filepath, socket, false, 
						Integer.parseInt(clientData.split(" ")[3])));
				this.terminateCommands.put(commandId, t);
				t.start();
			}
		}
		catch(FileNotFoundException e){
			System.out.println("File not found" + e);
		}
		catch(IOException ioe){
			System.out.println("IO Exception " + ioe);
		}
	}

	private static String interpret(String clientData) {
		if (clientData == null) {
			return null;
		}
		return clientData.split(" ")[0].toLowerCase();
	}

	int findLength(String fileName) {
		int length = -1;
		File file = new File(fileName);
		if (file.exists())
			length = (int) file.length();
		
		System.out.println("Server side call length "+length);
		return length;
	}

	private void executeGet(String path, Socket socket, boolean background) throws IOException {

		OutputStream outStr = socket.getOutputStream();
		Path p = Paths.get(path);
		File file = p.toFile();
		boolean fileExists = file.exists();

		System.out.println(background);
		if (background && fileExists) {
			String filepath = path;
			if (fileExists) {
				FileInputStream fis = new FileInputStream(file);
				byte[] fileBytes = new byte[(int) file.length()];
				fis.read(fileBytes);
				outStr.write(fileBytes);
				fis.close();
			}
		} 
		else {
			if (fileExists) {
				FileInputStream fis = new FileInputStream(file);
				byte[] fileBytes = new byte[(int) file.length()];
				fis.read(fileBytes);
				outStr.write(fileBytes);
				fis.close();
			}else{
				printWriter.println("Fail");
			}
		}
	}
}
