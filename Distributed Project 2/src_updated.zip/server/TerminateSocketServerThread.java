package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class TerminateSocketServerThread implements Runnable {
	private int tport = 0;

	ServerSocket terminateServerSocket = null;
	Socket terminateSocket = null;
	HashMap<Integer, Thread> terminateCommands;

	public TerminateSocketServerThread(int tport, HashMap<Integer, Thread> terminateCommands) {
		//System.out.println("In constructor of terminate thread SERVER");
		this.tport = tport;
		try {
			terminateServerSocket = new ServerSocket(tport);
			this.terminateCommands = terminateCommands;

		} catch (Exception e) {
			System.out.println("Exception in terminate thread creaation.. " + e.getMessage());
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		//System.out.println("in run of terminate thread SERVER");
		try {
			while (true) {
				terminateSocket = terminateServerSocket.accept();
				// spawn a terminate worker thread here
				new Thread(new TerminateWorkerThread(tport, terminateSocket, terminateCommands)).start();
			}
		} catch (IOException e) {
			System.out.println("Exception occured in getting client connection for terminate: " + e.getMessage());
			e.printStackTrace();
		}
	}

}
