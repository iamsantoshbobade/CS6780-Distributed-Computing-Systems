package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class NormalSocketServerThread implements Runnable {

	ServerSocket normalServerSocket = null;
	Socket normalSocket = null;
	HashMap<Integer, Thread> terminateCommands;
	private int nport;

	public NormalSocketServerThread(int nport, HashMap<Integer, Thread> terminateCommands) {
		//System.out.println("In constructor of normal thread");
		this.nport = nport;
		try {
			normalServerSocket = new ServerSocket(nport);
			this.terminateCommands = terminateCommands;

		} catch (IOException e) {
			System.out.println("Exception in normal thread creaation.. " + e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		//System.out.println("in run of normal thread thread");
		try {

			while (true) {
				normalSocket = normalServerSocket.accept();
				Thread t = new Thread(new ServerWorkerThread(normalSocket, terminateCommands));// .start();
				t.start();
				System.out.println("Client connected.. " + t.getId());

			}

		} catch (Exception e) {
			System.out.println("Exception occured in Normal Thread creation: " + e.getMessage());
			e.printStackTrace();
		}
	}

}
