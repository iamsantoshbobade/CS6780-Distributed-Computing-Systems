package server;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;

public class TerminateWorkerThread implements Runnable {

	int tport;
	Socket socket = null;
	HashMap<Integer, Thread> terminateCommands;
	BufferedReader bufferedReader = null;
	InputStream inputStream = null;
	PrintWriter printWriter = null;

	public TerminateWorkerThread(int tport, Socket socket, HashMap<Integer, Thread> terminateCommands) {
		this.terminateCommands = terminateCommands;
		this.tport = tport;
		this.socket = socket;
		// System.out.println("in constructor of terminate worker thread
		// SERVER");
	}

	private String terminateCommand(Integer commandId) {
		// System.out.println("Came to terminate methopd on SERVER");
		if (terminateCommands.containsKey(commandId)) {
			Thread thread = terminateCommands.get(commandId);
			System.out.println("Before:"+thread.isInterrupted());
			while (!thread.isInterrupted()) {
				System.out.println("in while lopp");
				thread.interrupt();

			}
			System.out.println("After :"+thread.isInterrupted());
			terminateCommands.remove(commandId);
			return "Success";
		}
		return "Failure";
	}

	@Override
	public void run() {

		System.out.println("Terminate Worker thread run method SERVER");

		try {
			inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();

			printWriter = new PrintWriter(outputStream, true);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String clientData = "";

			while (true) {
				clientData = bufferedReader.readLine();
				System.out.println("In Terminate Worker Thread SERVER side: " + clientData + "**");
				if (clientData != null) {
					Integer commandId = Integer.valueOf(clientData);
					String result = terminateCommand(commandId);
					//printWriter.println(result);
				}

			}

		} catch (Exception e) {
			System.out.println("Exception occured in run of Server Worker Thread: " + e.getMessage());
			e.printStackTrace();
		}

	}

}
