package code;

import java.io.BufferedOutputStream;
/**
 * @author Pranjay Patil
 * 		   Santosh Bobade
 * @version 1.0.0
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientSide {
	/**
	 * This method establishes a connection with the remote server.
	 * 
	 * @param port
	 *            - The port of the server machine
	 * @throws UnknownHostException
	 * @throws IOException
	 * 
	 */
	public static void startClient(String address, int port) throws UnknownHostException, IOException {
		Socket socket = null;

		try {

			socket = new Socket(address, port);
			OutputStream ops = socket.getOutputStream();
			// System.out.println(socket.getInetAddress().getLocalHost().getHostName());
			PrintWriter pw = new PrintWriter(ops, true);
			InputStream ips = socket.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			BufferedReader streamReader = new BufferedReader(new InputStreamReader(ips));
			String userInp = "";
			while (!userInp.equalsIgnoreCase("quit")) {
				System.out.print("myftp>");
				userInp = br.readLine();
				if (userInp.length() == 0) {
					continue;
				}
				pw.println(userInp);
				String command = userInp.split(" ")[0];
				String serverStream = null;
				String temp = "";
				// System.out.println("****"+serverStream+"*****");

				switch (command) {
				case "get":
					System.out.println("Waiting for file write to complete");
					Thread.sleep(300);
					InputStream ins = socket.getInputStream();
					FileOutputStream fos = new FileOutputStream(userInp.split(" ")[1]);
					while (ins.available() != 0) {
						fos.write(ins.read());
					}
					break;
				case "put":
					OutputStream outStr = socket.getOutputStream();
					File f = new File(userInp.split(" ")[1]);
					FileInputStream fis = new FileInputStream(f);
					int b = 0;
					while ((b = fis.read()) > -1 ) {
						outStr.write(b);
					}
					fis.close();
					break;
				default:
					serverStream = streamReader.readLine();
					if (serverStream != null && !serverStream.endsWith("IGNORE"))
						System.out.println(serverStream);

				}

				/*
				 * It surely works here. serverStream = streamReader.readLine();
				 * if (serverStream != null && !serverStream.endsWith("IGNORE"))
				 * System.out.println(serverStream);
				 */

			}

		} catch (Exception e) {
			System.out.println("Exception occured in Client: " + e.getMessage());
			socket.close();
		} finally {
			socket.close();

		}
	}

	public static void main(String args[]) throws UnknownHostException, IOException {
		startClient(args[0], Integer.parseInt(args[1])); // Using 1234 for
															// testing
	}
}