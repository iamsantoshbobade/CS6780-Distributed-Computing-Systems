package code;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSide {

	public static String PWD = "";
	public static int PORT = 0;

	public static void startServer(int port) throws IOException {
		ServerSocket ssocketObj = null;
		Socket socket = null;
		BufferedReader br = null;
		InputStream ips = null;
		PrintWriter pw = null;
		try {
			ssocketObj = new ServerSocket(port);
			socket = ssocketObj.accept();
			ips = socket.getInputStream();

			OutputStream ops = socket.getOutputStream();
			pw = new PrintWriter(ops, true);
			br = new BufferedReader(new InputStreamReader(ips));
			String clientData = "";
			PWD = null;
			if (PWD == null)
				PWD = System.getProperty("user.dir");
			while (true) {
				clientData = br.readLine();

				String command = interpret(clientData);

				switch (command) {
				case "get":
					String str = executeGet(PWD + "/" + clientData.split(" ")[1], socket);
					if (str != null && !str.endsWith("IGNORE")) {
						pw.println(str);
					}
					break;
				case "put":
					FileOutputStream fos = new FileOutputStream("new.txt");
					InputStream ins = socket.getInputStream();
					while (ins.available() != 0) {
						fos.write(ins.read());
					}
					break;

				case "mkdir":
					String words[] = clientData.trim().split(" ");

					if (words.length > 1) {
						File file = new File(PWD + "/" + words[1].trim());
						boolean fileExists = file.exists();
						if (!fileExists) {
							file.mkdir();
							pw.println("MKDIR COMMAND IGNORE");
						} else {
							pw.println("File: " + words[1].trim() + " already exists.");
						}
					} else {
						pw.println("mkdir: missing operand. \nCorrect usage: mkdir <directory-name>");
					}

					break;

				case "cd":
					words = clientData.trim().split(" ");
					if (words.length > 1) {
						if (words[1].trim().equals("..")) {
							int indexOfLastSlash = PWD.lastIndexOf('/');
							if (indexOfLastSlash != -1) {
								String temp = PWD.substring(0, indexOfLastSlash);
								PWD = temp;
								// pw.println(PWD);
								pw.println("CD COMMAND IGNORE");
								// pw.println();
							}

						} else {

							File f = new File(words[1].trim());
							if (f.exists() && f.isDirectory() && f.isAbsolute()) {
								PWD = words[1].trim();
								// pw.println(PWD);
								pw.println("CD COMMAND IGNORE");
							} else {
								File file = new File(PWD + "/" + words[1].trim());
								boolean fileExists = file.exists();
								boolean isFileAdirectory = file.isDirectory();
								if (fileExists) {
									if (isFileAdirectory) {
										PWD = PWD + "/" + words[1].trim();
										pw.println("CD COMMAND IGNORE");
									} else {
										pw.println("cd: " + words[1] + ": Not a directory");
									}
								} else {
									pw.println("cd: " + words[1] + ": No such file or directory");
								}
							}

						}
					} else {
						pw.println("cd: missing operand. \nOnly cd .. and cd <directory-name> are supported.");
					}

					break;
				case "delete":

					words = clientData.trim().split(" ");
					if (words.length > 1) {
						File file = new File(PWD + "/" + words[1].trim());
						boolean fileExists = file.exists();
						boolean isFileAdirectory = file.isDirectory();
						if (fileExists && !isFileAdirectory) {
							file.delete();
							pw.println("DELETE COMMAND IGNORE");
						} else if (isFileAdirectory) {
							pw.println(words[1] + " is a directory.\nCan not delete directory using delete.");
						}
					} else {
						pw.println("delete: missing operand. \nCorrect usage: delete <filename>");
					}
					break;
				case "ls":

					File file = new File(PWD);
					String directoryList[] = file.list();
					String temp = "";
					for (String directory : directoryList) {
						temp = temp + directory + "\t";
					}
					pw.println(temp);

					break;

				case "pwd":
					pw.println((InetAddress.getLocalHost().getHostName().toString() + PWD));
					break;
				case "quit":

					pw.println("QUIT COMMAND IGNORE");

					break;
				default:
					pw.println("Invalid command.");
					break;

				}
			}

		} catch (IOException e) {
			pw.println("Exception occured in StartServer method: " + e.getMessage());
		} finally {
			br.close();
			ips.close();
			socket.close();
			ssocketObj.close();
			startServer(PORT);
			PWD = System.getProperty("user.dir");

		}
	}

	private static String executeGet(String path, Socket socket) throws IOException {
		OutputStream outStr = socket.getOutputStream();
		File file = new File(path);
		boolean fileExists = file.exists();
		if (fileExists) {
			FileInputStream fis = new FileInputStream(file);
			int b = 0;
			while ((b = fis.read()) > -1) {
				outStr.write(b);
			}
			fis.close();
		} else {
			return "get: " + file.getName() + ": No such file or directory";
		}
		return "GET COMMAND IGNORE";

	}

	private static String interpret(String clientData) {
		return clientData.split(" ")[0];
	}

	public static void main(String args[]) throws IOException {
		PWD = null;
		PORT = 1234;
		startServer(1234);
	}
}